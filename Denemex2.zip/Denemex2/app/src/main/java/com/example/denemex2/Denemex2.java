package com.example.denemex2;

import java.util.Scanner;

public class Denemex2
{
    public static void main(String args[])
    {

        Scanner sc = new Scanner(System.in);
        System.out.print("Lütfen kisa kenar giriniz: ");
        float kisakenar = sc.nextFloat();
        System.out.print("Lütfen uzun kenar giriniz: ");
        float uzunkenar = sc.nextFloat();
        System.out.println("Girdiğiniz ölçülere göre alan : "+kisakenar*uzunkenar);
    }

}
