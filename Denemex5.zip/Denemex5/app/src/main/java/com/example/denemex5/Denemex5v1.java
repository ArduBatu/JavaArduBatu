package com.example.denemex5;

public class Denemex5v1
{
    public static void main (String[] args)
    {
        Denemex5 araba_bmw = new Denemex5();
        araba_bmw.color="Red";
        araba_bmw.velocity= 40;
        araba_bmw.distance= 200;
        araba_bmw.isworking= true;
        Denemex5 araba_tofas = new Denemex5();
        araba_tofas.color = "Blue";
        araba_tofas.velocity = 30;

        araba_tofas.distance = 400;
        araba_tofas.isworking = false;
        System.out.println(araba_tofas.color);
        System.out.println(araba_bmw.color);

    }
}
