package com.example.denemex5;

public class Denemex5
{
    String color;
    int velocity;
    double distance;
    boolean isworking;


}
