package com.example.denemex8;

public class Denemex7v1
{
    public static void main (String[] args)
    {
        OGRENCI ogrenci1 = new OGRENCI("Ahmet",234,"Malatya");
        OGRENCI ogrenci2 = new OGRENCI("Batu",344,"Adıyaman");
        System.out.println(ogrenci2.adres);
        System.out.println(ogrenci1.adres);
    }
}

