package com.example.denemex8;

public class OGRENCI
{
    String isim;
    int Okulno;
    String adres;
    public OGRENCI()
    {}
    public OGRENCI(String xisim,int xokulno,String xadres)
    {
        isim = xisim;
        Okulno= xokulno;
        adres = xadres;
    }

}
