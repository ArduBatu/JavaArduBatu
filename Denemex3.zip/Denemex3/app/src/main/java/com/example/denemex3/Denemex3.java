package com.example.denemex3;

import java.util.Scanner;

public class Denemex3
{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);

        System.out.print("lütfen sayı giriniz: ");
        float s1 = sc.nextFloat();
        System.out.print("Lütfen ikinci sayi giriniz: ");
        float s2 = sc.nextFloat();
        System.out.print("Toplama için 1\nÇıkarma için 2\nÇarpma için 3\nBölme için 4\n Tuşlarına basınız");
        int i = sc.nextInt();
        switch (i)
        {
            case (1):
                System.out.print("Sonuc"+(s1+s2));
            case (2):
                System.out.print("Sonuc"+(s1-s2));
            case (3):
                System.out.print("Sonuc"+(s1*s2));
            case (4):
                System.out.println("1.Sonuc"+(s1/s2));
                System.out.println("1.Sonuc"+(s2/s1));
        }
    }
}
