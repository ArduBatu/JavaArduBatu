package com.example.denemex6;

public class Matematik
{
    public static void cross1 (int sayi1,int sayi2)
    {
        int sonuc = sayi1*sayi2;
        System.out.println(sonuc);
    }
    public static void sum(int sayi1,int sayi2)
    {
        int sonuc = sayi1+sayi2;
        System.out.println(sonuc);
    }
}
