package com.example.denemex6;

import java.util.Scanner;

public class MatematikMain
{
    public static void main(String[] args)
    {
        Matematik m1 = new Matematik();
        m1.cross1(3,5);
        m1.sum(3,6);

    }
}
