package com.example.denemex1;

public class denemex1 {
    public static void main(String args[]) {
        int sayi1 = 23;
        int sayi2 = 44;
        String matin= "batu";
        if(sayi1 < sayi2)
        {
            System.out.println("bu dogru");
        }
        if (matin.equals("batu"))
        {
            System.out.println("batu yazdı");
        }else{
            System.out.println("batu yazmadı");
        }

    }


}

