package com.example.denemex7;

public class Denemex7v1
{
    public static void main (String[] args)
    {
        Islemler m1 = new Islemler();
        double a = m1.orthesaplama(4,5,6);
        System.out.println(a);
    }
}
