package com.example.denemex7;

public class Islemler
{
    public double  orthesaplama(double... sayilar)
    {
        double toplam = 0;
        for (Double d: sayilar)
        {
            toplam = toplam+d;
        }
        return toplam/sayilar.length;
    }
}
