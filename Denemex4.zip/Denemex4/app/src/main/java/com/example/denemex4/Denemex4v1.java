package com.example.denemex4;

import android.text.style.EasyEditSpan;

import java.util.Scanner;

public class Denemex4v1
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        int[] Sayi= new int [5];

        for(int i=0;i<Sayi.length;i++)
        {
            System.out.print("Sayı giriniz: ");
            int eklenecek_sayi = sc.nextInt();
            Sayi[i] = eklenecek_sayi;
        }
        for (int k:Sayi)
        {
            System.out.println(k);
        }
    }
}
