package com.example.denemex4;

import android.telephony.mbms.StreamingServiceInfo;

import java.util.Scanner;

public class Denemex4
{
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] meyveler = {"Elma", "armut", "patates"};
        for (String i:meyveler)
        {
            System.out.println(i);
        }
    }
}

