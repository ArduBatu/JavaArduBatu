package com.example.denemex9;

import java.util.Scanner;

public class santitofahre //Santigratı Fahrenheite çeviren programı yazacağız.
{
    public static void main(String [] args)
    {
        Scanner sw = new Scanner(System.in);
        System.out.print("Lütfen santigrat dereceyi giriniz: ");
        double santigrat = sw.nextDouble();
        double fahrenheit=(santigrat*1.8)+32;
        System.out.println("Fahrenheit değeri: "+fahrenheit);

    }
}
