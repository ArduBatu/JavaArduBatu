package com.example.denemex10;

import java.util.Scanner;

public class faktorıyel
{
    public static void main(String[] args)
    {
        while(true)
        {
            Faktoriyelhesapla faktoriyel = new Faktoriyelhesapla();
            Scanner sc = new Scanner(System.in);
            System.out.print("Lütfen Faktoriyeli hesaplayacagımız sayı giriniz(9999 çıkıştır): ");
            int b = sc.nextInt();
            int sonucumuz = faktoriyel.faktoriyelhesapla(b);
            if (b==9999)
            {
                break;
            }
            else
            {
                System.out.println(sonucumuz);
            }


        }

    }
}