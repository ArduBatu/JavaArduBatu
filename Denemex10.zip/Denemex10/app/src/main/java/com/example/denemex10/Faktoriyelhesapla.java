package com.example.denemex10;

public class Faktoriyelhesapla
{
    public int faktoriyelhesapla(int sayi1)
    {
        int sonuc =1;
        if (sayi1==0)
        {
            sonuc=1;
        }
        else
        {
           for (int i=1;i<sayi1+1;i++)
           {
               sonuc *= i;
           }
        }
        return sonuc;
    }
}
