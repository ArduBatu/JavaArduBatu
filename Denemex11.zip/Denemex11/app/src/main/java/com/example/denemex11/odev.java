package com.example.denemex11;

public class odev
{
    public void harfsayisibul(String kelime,char harf)
    {
        int boyut = kelime.length();
        char [] harfler =new char[boyut];
        for (int i=0;i<boyut;i++)
        {
            harfler[i]= kelime.charAt(i);
        }
        int sayac =0;
        for (int i=0;i<boyut;i++)
        {
            if( harfler[i]==harf)
            {
                sayac++;
            }
        }
        System.out.println("Aradığnız harf sayısı: "+sayac);
    }
}
