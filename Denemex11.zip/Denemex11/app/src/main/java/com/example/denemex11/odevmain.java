package com.example.denemex11;

import java.util.Scanner;

public class odevmain
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Harf sayısını bulmak istediğiniz kelimeyi yazınız: ");
        String a = sc.next();
        System.out.println("Hangi harfin sayısını bulmak istiyorsunuz: ");
        char b= sc.next().charAt(0);
        odev n1 =new odev();
        n1.harfsayisibul(a,b);
    }

}
